Bukhari Network Recharge Slip - Android source project

This is an initial offline Android app project. It stores recharge history locally on the device and generates A4 or small-format PDF slips. Company and bank details can be entered in the form each time; persistent company settings and a richer history manager are planned for a later version.

Build requirements: JDK 17, Gradle 8.9, Android Gradle Plugin 8.7.3, Android SDK Platform 35.

GitHub Actions workflow expects this project folder to be extracted as bukhari-recharge-slip and then runs: gradle assembleDebug
