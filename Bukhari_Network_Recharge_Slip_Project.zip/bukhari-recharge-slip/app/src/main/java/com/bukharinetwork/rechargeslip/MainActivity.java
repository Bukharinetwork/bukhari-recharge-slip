package com.bukharinetwork.rechargeslip;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.content.*;
import android.net.Uri;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, form; EditText company, address, bank, account, iban, customer, customerAddress, pppoe, pack, speed, amount, recharge, expiry, remarks;
    Spinner status; TextView history; ArrayList<String> records = new ArrayList<>();
    int navy=Color.rgb(7,59,103), blue=Color.rgb(8,119,201);
    public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(navy); getWindow().setNavigationBarColor(navy); load(); build(); }
    void load(){ String raw=getPreferences(0).getString("history",""); if(!raw.isEmpty()) records.addAll(Arrays.asList(raw.split("\\n"))); }
    void save(){ getPreferences(0).edit().putString("history",android.text.TextUtils.join("\n",records)).apply(); }
    void build(){
        ScrollView scroll=new ScrollView(this); root=new LinearLayout(this); root.setOrientation(1); root.setPadding(18,18,18,28); root.setBackgroundColor(Color.rgb(245,248,252)); scroll.addView(root); setContentView(scroll);
        TextView title=new TextView(this); title.setText("BUKHARI NETWORK\nRecharge Slip Generator"); title.setTextColor(Color.WHITE); title.setTextSize(23); title.setGravity(17); title.setPadding(12,24,12,24); title.setBackgroundColor(navy); root.addView(title);
        section("Company & Bank Details"); company=field("Company name","Bukhari Network"); address=field("Office address","Dhabeji Market, Main National Highway Road"); bank=field("Bank name"); account=field("Account title"); iban=field("Account number / IBAN");
        section("Customer & Recharge Details"); customer=field("Customer name"); customerAddress=field("Customer address"); pppoe=field("PPPoE username / User ID"); pack=field("Package name"); speed=field("Speed (Mbps)"); amount=field("Recharge amount (PKR)"); recharge=field("Recharge date (e.g. 10-11-2026)",today()); expiry=field("Expiry date");
        status=new Spinner(this); ArrayAdapter<String> a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Paid","Unpaid","Partial"}); status.setAdapter(a); root.addView(label("Payment status")); root.addView(status); remarks=field("Remarks");
        Button pdf=button("Generate PDF Slip (A4)"); pdf.setOnClickListener(v->generate(false)); root.addView(pdf);
        Button receipt=button("Generate PDF Slip (Small Receipt)"); receipt.setOnClickListener(v->generate(true)); root.addView(receipt);
        Button saveBtn=button("Save Recharge & View History"); saveBtn.setOnClickListener(v->{ records.add(0,customer.getText()+" | "+pppoe.getText()+" | Rs "+amount.getText()+" | "+recharge.getText()+" | "+status.getSelectedItem()); save(); refreshHistory(); Toast.makeText(this,"Recharge saved on this phone",0).show(); }); root.addView(saveBtn);
        history=new TextView(this); history.setTextColor(navy); history.setTextSize(14); history.setPadding(8,18,8,8); root.addView(history); refreshHistory();
        TextView foot=new TextView(this); foot.setText("Offline app • Data stays on this device"); foot.setTextColor(Color.GRAY); foot.setGravity(17); foot.setPadding(8,20,8,8); root.addView(foot);
    }
    String today(){return new SimpleDateFormat("dd-MM-yyyy",Locale.getDefault()).format(new Date());}
    TextView label(String s){TextView t=new TextView(this);t.setText(s);t.setTextColor(navy);t.setTextSize(14);t.setPadding(2,8,2,2);return t;}
    void section(String s){TextView t=label(s);t.setTextSize(18);t.setTypeface(null,1);t.setPadding(2,18,2,6);root.addView(t);}
    EditText field(String hint){return field(hint,"");}
    EditText field(String hint,String val){root.addView(label(hint)); EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(15);e.setPadding(12,4,12,4);e.setBackgroundColor(Color.WHITE);e.setHint(hint);e.setText(val);root.addView(e,new LinearLayout.LayoutParams(-1,54));return e;}
    Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=12;b.setLayoutParams(p);return b;}
    String val(EditText e){return e.getText().toString().trim();}
    void refreshHistory(){if(history!=null){StringBuilder s=new StringBuilder("Recharge History\n"); if(records.isEmpty())s.append("No saved recharges yet."); else for(int i=0;i<Math.min(30,records.size());i++)s.append("\n• ").append(records.get(i)); history.setText(s.toString());}}
    void generate(boolean small){
        if(val(customer).isEmpty()||val(amount).isEmpty()){Toast.makeText(this,"Customer name aur amount zaroor likhein",0).show();return;}
        try{
            int w=small?420:595,h=small?650:842; PdfDocument doc=new PdfDocument(); PdfDocument.PageInfo info=new PdfDocument.PageInfo.Builder(w,h,1).create(); PdfDocument.Page page=doc.startPage(info); Canvas c=page.getCanvas(); Paint p=new Paint(3);
            p.setColor(navy);c.drawRect(0,0,w,100,p);p.setColor(Color.WHITE);p.setTextSize(small?22:28);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));c.drawText(val(company).isEmpty()?"BUKHARI NETWORK":val(company),24,42,p);p.setTextSize(13);p.setTypeface(Typeface.DEFAULT);c.drawText("INTERNET RECHARGE SLIP",24,72,p);
            p.setColor(Color.DKGRAY);p.setTextSize(15);int y=135,step=small?34:42;String[][] rows={{"Office",val(address)},{"Bank",val(bank)},{"Account title",val(account)},{"Account / IBAN",val(iban)},{"Customer",val(customer)},{"Address",val(customerAddress)},{"PPPoE / User ID",val(pppoe)},{"Package",val(pack)},{"Speed",val(speed)+" Mbps"},{"Amount","Rs. "+val(amount)},{"Recharge date",val(recharge)},{"Expiry date",val(expiry)},{"Payment status",status.getSelectedItem().toString()},{"Remarks",val(remarks)}};
            for(String[] r:rows){p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));c.drawText(r[0]+":",24,y,p);p.setTypeface(Typeface.DEFAULT);String text=r[1].isEmpty()?"-":r[1];c.drawText(text.length()>42?text.substring(0,42):text,small?145:175,y,p);y+=step;}
            p.setColor(blue);c.drawRect(24,h-75,w-24,h-73,p);p.setColor(Color.DKGRAY);p.setTextSize(12);c.drawText("Thank you for choosing Bukhari Network",24,h-48,p);c.drawText("Generated: "+today(),24,h-28,p);doc.finishPage(page);
            File dir=new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),"BukhariSlips");dir.mkdirs();String name="Recharge_"+System.currentTimeMillis()+".pdf";File file=new File(dir,name);FileOutputStream out=new FileOutputStream(file);doc.writeTo(out);out.close();doc.close();
            Uri uri=androidxUri(file);Intent share=new Intent(Intent.ACTION_SEND);share.setType("application/pdf");share.putExtra(Intent.EXTRA_STREAM,uri);share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(share,"Save or share recharge slip"));
        }catch(Exception e){Toast.makeText(this,"PDF error: "+e.getMessage(),1).show();}
    }
    Uri androidxUri(File f){return Uri.fromFile(f);}
}
